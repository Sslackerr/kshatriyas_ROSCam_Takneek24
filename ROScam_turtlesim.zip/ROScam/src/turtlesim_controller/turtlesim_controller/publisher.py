import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math
import time

class TurtleQuadrilateralController(Node):
    def __init__(self, corners):
        super().__init__('turtle_quadrilateral_controller')
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.subscription = self.create_subscription(Pose, '/turtle1/pose', self.update_pose, 10)
        self.pose = None
        self.corners = corners
        self.target_reached = False
        self.initial_corner_reached = False
        self.current_corner_idx = 0  # Start at the first corner

    def update_pose(self, data):
        """Callback to update the turtle's current position."""
        self.pose = data

    def traverse_quadrilateral(self):
        """First move to the first corner, then traverse the quadrilateral."""
        while self.pose is None:
            rclpy.spin_once(self)

        # Step 1: Move the turtle to the first corner
        if not self.initial_corner_reached:
            target_x, target_y = self.corners[0]
            self.move_to_target(target_x, target_y)
            self.initial_corner_reached = True
            print("Reached the first corner!")

        # Step 2: Traverse the quadrilateral, returning to the first corner
        # The loop will move the turtle through all corners including returning to the first one.
        for i in range(len(self.corners)):
            next_corner_idx = (self.current_corner_idx + 1) % len(self.corners)
            target_x, target_y = self.corners[next_corner_idx]
            self.move_to_target(target_x, target_y)
            self.current_corner_idx = next_corner_idx

        # Move back to the first corner to complete the quadrilateral
        target_x, target_y = self.corners[0]
        self.move_to_target(target_x, target_y)

        # Stop the turtle after completing the quadrilateral
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.publisher.publish(twist)
        print("Completed the quadrilateral!")

    def move_to_target(self, target_x, target_y):
        """Move the turtle from its current position to the target coordinate."""
        while not self.target_reached:
            # Step 1: Calculate the distance and angle to the target
            distance = self.calculate_distance(self.pose.x, self.pose.y, target_x, target_y)
            angle_to_target = self.calculate_angle_to_target(self.pose.x, self.pose.y, target_x, target_y)

            twist = Twist()

            # Step 2: Rotate the turtle to face the target (no need for angle_error)
            twist.linear.x = 0.0
            twist.angular.z = 0.5 * (angle_to_target - self.pose.theta)

            # If the angle is small enough, start moving forward
            if abs(angle_to_target - self.pose.theta) < 0.01:
                # Step 3: Move forward if the angle is correct
                twist.linear.x = min(1.0, distance)  # Cap speed
                twist.angular.z = 0.0

            # Publish the command to move the turtle
            self.publisher.publish(twist)

            # Check if the target is reached
            if distance < 0.1:  # Target is considered reached if close enough
                self.target_reached = True
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.publisher.publish(twist)  # Stop the turtle

            rclpy.spin_once(self)

        # Reset target reached flag for the next corner
        self.target_reached = False

    def calculate_distance(self, x1, y1, x2, y2):
        """Calculate the Euclidean distance between two points."""
        return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

    def calculate_angle_to_target(self, x1, y1, x2, y2):
        """Calculate the angle between the current position and the target."""
        return math.atan2(y2 - y1, x2 - x1)

def main(args=None):
    rclpy.init(args=args)

    # Define the corners of the quadrilateral (example coordinates)
    corners = [[2.0, 2.0], [10.0, 2.0], [6.0, 6.0], [2.0, 6.0]]
    for i in corners:
        

    turtle_controller = TurtleQuadrilateralController(corners)
    turtle_controller.traverse_quadrilateral()

    turtle_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
