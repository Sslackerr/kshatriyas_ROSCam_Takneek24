import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray

class CornerPublisher(Node):
    def __init__(self):
        super().__init__('corner_publisher')
        self.publisher_ = self.create_publisher(Int32MultiArray, 'corner_coordinates', 10)

        # Delay for 1 second before publishing to ensure the system is ready
        self.timer = self.create_timer(1.0, self.publish_corners)

    def publish_corners(self):
        # Publish the corners once and then stop the timer
        msg = Int32MultiArray()
        corners = [2, 2, 6, 2, 6, 6, 2, 6]  # 4 corners, each with (x, y)
        msg.data = corners

        # Publish the message
        self.publisher_.publish(msg)
        self.get_logger().info(f"Published corners: {msg.data}")

        # Stop the timer after publishing once
        self.timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    node = CornerPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
